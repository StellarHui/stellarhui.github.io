---
title: 计算机网络：Introduction to Computer Network
categories: 计算机网络
tags:
mathjax: true
---

## Basics

### Access to Information

- **Client-Server Model**: a client explicitly requests information from a server that hosts that information.

  💡**Example**: web applications. 
  
  💡**Implementation**: request-reply model.

![](image-20250922101015164.png)

- **Peer-to-Peer Communication**: every person can, in principle, communicate with others in the same group. Every person can thus act both as a client and a server.

  💡**Example**: IoT.

  💡**Implementation**: When a client wants to acquire some content, 
  
  - 【从Torrent Repository Server处获取Tracker地址】The first step (1) is to get **a meta-data file** from a public web server hereafter called **Torrent Repository Server**（种子文件服务器）. This file contains **the address of one or more Trackers** and information about the content. 
  - 【从Tracker处获取Peers地址】The next step (2) performed by the Client is to **announce to the Tracker its desire to join the swarm**, which is answered with a list of Peers sharing the same content. This announce is performed periodically, so that the Tracker can keep the list of Peers updated.注意：Tracker不存储文件内容，而是协调用户之间的连接。它**记录哪些用户共享同一个文件**，帮助新加入的用户找到其他可连接的peer。
  - 【从Peers处获取所需文件块】Finally, the last step (3) is to try to establish connections with other peers in order to start sending and receiving content. These connections operate over TCP and use the PeerWire Protocol.

![](image-20250922101129617.png)

> 上图中，BitTorrent将文件分块下载，用户可以从多个peer同时下载（或上传）不同块，提高效率。Seeder（做种者）表示拥有全部文件的peer，只能上传文件块；Leecher（吸附者）表示拥有部分文件的peer，可以同时上传或下载文件块。

## Types of Computer Networks

### Broadband Access Networks 

- **功能**: 提供接入互联网（如Internet）的途径（via copper (telephone lines), coaxial cable (cable), optical fiber, or mobile (wireless medium)）。

> **Metcalfe’s Law**: the value of a network is proportional to **the square of the number of users**（$O(n^2)$） because this is roughly **the number of different connections that may be made.** 

### Mobile and Wireless Access Networks

- **功能**: 提供随时随地的无线连接。例如：(1) wireless networks: cellular networks, wireless hotspots; (2) mobile networks: mobile computers, such as laptops, tablets, and smartphones.

对比 wireless 与mobile：

![ ](image-20250922111831566.png)

### Content Provider Networks

- **功能**：托管大量服务器（数十万至百万级别）；支持云计算服务；处理服务器间及与互联网间的大规模数据传输。例如：Data-Center Networks / Cloud。

- **关键指标**：（1）网络吞吐量（cross-section bandwidth）：data rate that can be delivered between any two servers in the network（2）能耗（energy usage）。

### Content Delivery Network, CDN

- **功能**（特点）：(1) A large collection of servers that are geographically distributed; (2) **content is replicated** and placed as close as possible to the users that are requesting it.

![ ](image-20250922112724151.png)

### Transit Networks

- **功能**：在不同网络（e.g., between the **content provider** to **a user’s Internet Service Provider (ISP)** when they are not directly connected）之间传输流量。

> **注**：大流量之间更倾向于直接互联，减少对传输网络的依赖。

### Enterprise Networks

- **功能**：内部资源共享（数据、计算资源）；通信（邮件、VoIP、视频会议、远程医疗）；业务电子化。
- **实现**：（1）虚拟专用网络（VPN）连接不同个人网络；（2）使用一些传输介质：Email, IP telephony / voice over IP (VoIP), video meeting/conference, desktop sharing, telemedicine...

## Various Networking Technologies (that implement networks at different scales)

### PAN, Personal Area Network

- **范围**：个人设备之间（如蓝牙）。

### LAN, Local Area Network

- **范围**：单一建筑内（家、办公室、工厂）。

![](image-20250922115305907.png)

- **类型**：
  - **无线LAN（WLAN）**：通过AP（Access Point）接入，使用IEEE 802.11（WiFi）。其速度范围：11 Mbps (802.11b) to 7 Gbps (802.11ad)；
  - **有线LAN**：使用copper, coaxial cable, and optical fiber连接到交换机（Ethernet switch），IEEE 802.3（Ethernet）。其速度范围：100 Mbps to 40 Gbps，相比WLAN有lower latency, lower packet loss, and higher throughput。
  - **虚拟LAN（VLAN）**：逻辑上划分多个LAN，隔离通信。（VLAN divides one large physical LAN into smaller logical LANs, as if two separate physical LANs.）

> **AP:** can be a wireless router, or a base station. AP relays packets (1) between wireless computers and also (2) between wireless computers and the Internet.
>
> **Switch:** relays packets between computers, using address in packet to determine the destination computer.

### **Home Networks**

### **MAN, Metropolitan Area Network**

- **范围**：城市范围。例如：有线电视网络；WiMAX（IEEE 802.16）；4G/5G蜂窝网络。

### **WAN, Wide Area Networks**

- **范围**：跨越大地理区域。
- **组成**：（1）传输线（移动数据）；（2）路由器（转发数据）。

![](image-20250922120809793.png)

> **路由器相关的算法**：
>
> （1）路由算法（routing algorithm）：选择转发的路径（已知从router A到router B）；
>
> （2）转发算法（Forwarding algorithm）：选择转发对象（即转发决策，如router A选择转发到router B1 or B2 or B3）。

- **实现**：（1）使用VPN；（2）使用ISP；（3）使用卫星、蜂窝网络、SD-WAN等。

### **Internetworks / Internet**

- **定义**：由多个独立运营的网络互联而成。使用**网关**（Gateway）提供网络间的硬件和软件转换。

## Internet Designs in History

### **ARPANET**

- **特点**：the first store-and-forward packet-switching network.
